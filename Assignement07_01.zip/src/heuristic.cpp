#include "heuristic.h"

heuristic::heuristic()
{
    //ctor
}

heuristic::~heuristic()
{
    //dtor
}
