#ifndef HEURISTIC_H
#define HEURISTIC_H


class heuristic
{
    public:
        heuristic();
        virtual ~heuristic();
    protected:
    private:
};

#endif // HEURISTIC_H
