#ifndef AAA_H
#define AAA_H


class aaa
{
    public:
        aaa();
        virtual ~aaa();
    protected:
    private:
};

#endif // AAA_H
